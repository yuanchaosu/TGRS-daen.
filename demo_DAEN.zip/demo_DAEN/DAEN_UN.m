function [W,H,num_autoencoders] = DAEN_UN(Y,varargin)
% Input:
% Y is hyperspectral Data(bands*pixels);
% [W,H] = DAEN_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations);
% varargin contains endmembers number=numEndms, maxIterations, library specra, and display.

% 'DELTA' is balance coefficient.
% 'NUM_ENDMS' is the number of endmembers.
% 'MAX_ITERATION' is the maximum of iterations.

% Output:
% W is weight matrix bewteen hidden layer and out layer, and it is regarded as endmebers matrix.
% H is abundance matrix estimated from hidden layer.
% num_autoencoders is the number of autoencoders in the stacked network.
%% stacked AEs
currentFolder = pwd;
addpath(genpath(currentFolder))
VCAcandidate=30;
FmaxIters=500;
max_num_autoencoders=15;
[Y,num_autoencoders] = stackedAEs(Y,VCAcandidate,max_num_autoencoders,FmaxIters);
%%
% M_true = [];
% plot_a_t = 'no';
if (nargin-length(varargin)) ~= 1
    error('Wrong number of required parameters');
elseif (rem(length(varargin),2)==1)
    error('Optional input parameters should always go by pairs');
else
for i=1:2:(length(varargin)-1)
   switch upper(varargin{i})
   case 'DELTA'
         delta = varargin{i+1};
   case 'NUM_ENDMS'
         numEndms = varargin{i+1};% numEndms is the number of endmembers
   case 'MAX_ITERATION'
         maxIterations = varargin{i+1};% maxIterations is the maximum iteration for the VAE network
%    case 'TRUE_M'
%          M_true = varargin{i+1};%True endmembers
%    case 'PLOT_W'
%          plot_a_t = varargin{i+1};%display
   otherwise
                % Hmmm, something wrong with the parameter string
   error(['Unrecognized option: ''' varargin{i} '''']);
   end;
end;
Iterations =0;
v='off';
[Bands,Pixels] = size(Y);
[InitialW, ~, ~ ]= VCA(Y,'Endmembers',numEndms,'verbose',v);
InitialH = zeros(length(InitialW(1,:)),Pixels);
endm = [1e-5*InitialW;ones(1,length(InitialW(1,:)))];
for i=1:Pixels
    Rmixed = [1e-5*Y(:,i); 1];
    InitialH(:,i) = lsqnonneg(endm,Rmixed);
end
InitialW=abs(InitialW);
W = InitialW;
H = InitialH;

RMSE = sum(sum((Y-W*H).^2)); % RMSE for intergrated autoencoder network 
RMSE = [RMSE, 0];
%% Training
for Iteration = 1:maxIterations
Iterations = Iterations +1;
disp(['number of iterations' num2str(Iterations) '/' num2str(maxIterations)]);% exhibit Iteration
% [hint1,hint2] = judge(RMSE,Iteration);
% estimation for variational autoencoder
Error = Y - W*H;
para = Bands*Pixels/2;
% objective function
para2 = sum((sum(Error.^2,1)/2))';
Objective1 = delta * (1/gamrnd(para,1./para2));

% randomization
random = randperm(numEndms);
[Z,Ya,Wa,pro,zt,thet,select]=randp(random,numEndms,W,H,Y);

% hidden layers 
for i=1:Pixels
    eps = inv(thet/Objective1);
    Mu = eps * ((1/Objective1)*(zt-pro)'*(Ya(i,:)'-Wa(select,:)'));
% hidden variable 
    Z(i,:) = combi(Z(i,:),Mu,eps); 
end
% constrain abundance
Ha = constrain(random,numEndms,Z);

H = Ha';% obtain abundance
% Assure weight W of decoder, and W equals endmember matrix.

maxiteraion=50; %learning endmember
lam = 1 - delta;
[W] = endm_minv(Y,W,H,maxiteraion,lam,numEndms); % MinVol constrain endmembers
ObNew = sum(sum((Y-W*H).^2));
RMSE = [RMSE, ObNew];
end
end