function [W] = endm_minv(Y,W,H,maxiteraion,lam,numEndms)
 [PC, ~] = pca(Y'); 
 D = PC(:,1:numEndms-1);
 RR=Y';
 meanData = mean(RR); 
 m=numEndms;
 inp = Y; 
 PP = H*H';
 nn = -0.001;
 decayP = 0;    
 decayN = 1;    
 B = [ones(1,m); zeros(m-1,m)];
 C = [zeros(1,m-1); eye(m-1)]*D';
 meanData = meanData'*ones(1,m);
 I = B+C*(W-meanData);
 detz2 = det(I)^2;
 ID = pinv(I)*C;
 tWp = H*H'*W' - H*inp' + lam * detz2 * ID;
 conjp = tWp;
 W = W + nn*tWp';
 for iteration = 1:maxiteraion
     I = B+C*(W-meanData);
     detz2 = det(I)^2;
     ID = pinv(I)*C;
     tWpp = H*H'*W' - H*inp' + lam * detz2 * ID;
     beta = abs(sum(tWpp.*(tWpp-tWp),1)./(sum(tWp.^2,1)));
     conj = -tWpp+ones(m,1)*beta.*conjp;
     AAd = H*H'*conj;
     alpha = sum(conj.*(-tWpp),1)./max(sum(conj.*AAd,1),eps);
     tW = W' + conj.*repmat(alpha,size(PP,2),1);
     W=tW';
 %% decay function for negative weights
     if  decayP > 0
         idx = find(W > 0);
         W(idx) = W(idx) - decayP * W(idx);
     end               
     if  decayN == 1
         W = max(W, 0);
     elseif decayN > 0
         idx = find(net.W < 0);
         W(idx) = W(idx) - decayN * W(idx);
     end
     tWp = tWpp;
     conjp = conj;
 end
end