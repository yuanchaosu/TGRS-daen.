clear;
clc;
close all
% The synthetic data has 224 bands * 676 pixels
% SNR = 50dB;
% MaxPurity = 0.8;
currentFolder = pwd;
addpath(genpath(currentFolder))
load Data;
M = True_M;% library signatures
%% attention 

test = 1; % test VAE
% test = 2; % comparing other methods
% test  =3; % test DAEN. DAEN = Stacked AEs + VAE. Note that the stacked AE network needs high computation. 

%%
switch test
    
case 1  
delta = 0.99;
numEndms=4;% The number of endmembers
maxIterations=300;
% unmixing
[W,H] = VAE_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations,'TRUE_M',M,'PLOT_W','yes');

Endmembers = W;% weight matrix=endmembers
Abundance = H;% abundance is from hidden-layers

% display
figure('NumberTitle', 'off', 'Name', 'Comparing endmembers');
Sh1 = plot(Endmembers,'r','LineWidth',3);
hold on
Sh2 = plot(M,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);

figure('NumberTitle', 'off', 'Name', 'Reconstructed data');
colormap(gray)
RecY = W*H; % constructed data
subplot(211)
imagesc(Y);title('Y')
subplot(212)
imagesc(RecY);title('Reconstructed Y')
case 2
%%
m=4;
% Test N-FINDR
[numBands,Newpixels]=size(Y);
img = reshape(Y.', 1, Newpixels, numBands); 
[nfindrEndms,~] = NFINDR(img,m);

% Test VCA
v='off';
[A_vca, ~, ~ ]= VCA(Y,'Endmembers',m,'verbose',v);
vcaEndms=A_vca;

% Test VAE
M = True_M;
delta = 0.99;
numEndms=4;% The number of endmembers
maxIterations=300;
% unmixing
[W,H] = VAE_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations,'TRUE_M',M,'PLOT_W','no');

figure ('NumberTitle', 'off', 'Name', 'N-FINDR');
plot(nfindrEndms,'r','LineWidth',3);
hold on
plot(M,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('NFINDR');
hold off

figure ('NumberTitle', 'off', 'Name', 'VCA');
plot(vcaEndms,'r','LineWidth',3);
hold on
plot(M,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('VCA');
hold off

figure('NumberTitle', 'off', 'Name', 'VAE');
Sh1 = plot(W,'r','LineWidth',3);
hold on
Sh2 = plot(M,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('VAE');
hold off
case 3
% The synthetic data has 224 bands * 1764 pixels
% SNR = 50dB;
% MaxPurity = 0.8;
% Exist 10 outliers.
load Data_10_outliers;
Y=Y2;
M = M2;% library signatures
delta = 0.99;
numEndms=4;% The number of endmembers
maxIterations=300;
[W,H] = DAEN_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations);
[W2,~] = VAE_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations,'TRUE_M',M,'PLOT_W','no');
[numBands,Newpixels]=size(Y);
img = reshape(Y.', 1, Newpixels, numBands); 
[nfindrEndms,~] = NFINDR(img,numEndms);
v='off';
[A_vca, ~, ~ ]= VCA(Y,'Endmembers',numEndms,'verbose',v);
vcaEndms=A_vca;

figure('NumberTitle', 'off', 'Name', 'VAE');
plot(W,'r','LineWidth',3);
hold on
plot(M2,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('DAEN');
hold off
figure('NumberTitle', 'off', 'Name', 'VAE');
plot(W2,'r','LineWidth',3);
hold on
plot(M2,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('VAE');
hold off
figure ('NumberTitle', 'off', 'Name', 'N-FINDR');
plot(nfindrEndms,'r','LineWidth',3);
hold on
plot(M2,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('NFINDR');
hold off
figure ('NumberTitle', 'off', 'Name', 'VCA');
plot(vcaEndms,'r','LineWidth',3);
hold on
plot(M2,'-.','color',[0,0.45,0.74],'LineWidth',3);
ylabel('reflectance','fontsize',20);
xlabel('bands','fontsize',20);
set(gca,'FontSize',15);
title('VCA');
hold off
end