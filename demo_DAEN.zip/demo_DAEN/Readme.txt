Demo
DAEN is composed by stacked AEs and VAE. 
test = 1 shows the unmixing results of VAE.
test = 2 is a comparsion of different methods
test = 3 shows the results of DAEN. Note that DAEN needs more time to run, due to the stacked AE network with high computation. 