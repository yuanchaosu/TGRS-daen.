function [W,H] = VAE_UN(Y,varargin)
% Input:
% Y is hyperspectral Data(bands*pixels);
% [W,H] = VAE_UN(Y,'DELTA',delta,'NUM_ENDMS',numEndms,'MAX_ITERATION',maxIterations,'TRUE_M',M,'PLOT_W','yes');
% varargin contains endmembers number=numEndms, maxIterations, library specra, and display.

% 'DELTA' is balance coefficient.
% 'NUM_ENDMS' is the number of endmembers.
% 'MAX_ITERATION' is the maximum of iterations.
% 'TRUE_M' is real library spectra which is used to test extracted endmembers
% 'PLOT_W' is illustration for the process.(yes or no)

% Output:
% W is weight matrix bewteen hidden layer and out layer, and it is regarded as endmebers matrix.
% H is abundance matrix estimated from hidden layer.
% The function is writed by Yuanchao, 2017
%% Initialization
currentFolder = pwd;
addpath(genpath(currentFolder))

M_true = [];
plot_a_t = 'no';
if (nargin-length(varargin)) ~= 1
    error('Wrong number of required parameters');
elseif (rem(length(varargin),2)==1)
    error('Optional input parameters should always go by pairs');
else
for i=1:2:(length(varargin)-1)
   switch upper(varargin{i})
   case 'DELTA'
         delta = varargin{i+1};
   case 'NUM_ENDMS'
         numEndms = varargin{i+1};% numEndms is the number of endmembers
   case 'MAX_ITERATION'
         maxIterations = varargin{i+1};% maxIterations is the maximum iteration for the VAE network
   case 'TRUE_M'
         M_true = varargin{i+1};%True endmembers
   case 'PLOT_W'
         plot_a_t = varargin{i+1};%display
   otherwise
                % Hmmm, something wrong with the parameter string
   error(['Unrecognized option: ''' varargin{i} '''']);
   end;
end;
Iterations =0;
v='off';
[Bands,Pixels] = size(Y);
[InitialW, ~, ~ ]= VCA(Y,'Endmembers',numEndms,'verbose',v);
InitialH = zeros(length(InitialW(1,:)),Pixels);
endm = [1e-5*InitialW;ones(1,length(InitialW(1,:)))];
for i=1:Pixels
    Rmixed = [1e-5*Y(:,i); 1];
    InitialH(:,i) = lsqnonneg(endm,Rmixed);
end
InitialW=abs(InitialW);
W = InitialW;
H = InitialH;

RMSE = sum(sum((Y-W*H).^2)); % RMSE for intergrated autoencoder network 
RMSE = [RMSE, 0];
%% Training
for Iteration = 1:maxIterations
Iterations = Iterations +1;
disp(['number of iterations' num2str(Iterations) '/' num2str(maxIterations)]);% exhibit Iteration
% [hint1,hint2] = judge(RMSE,Iteration);
% estimation for variational autoencoder
Error = Y - W*H;
para = Bands*Pixels/2;
% objective function
para2 = sum((sum(Error.^2,1)/2))';
Objective1 = delta * (1/gamrnd(para,1./para2));

% randomization
random = randperm(numEndms);
[Z,Ya,Wa,pro,zt,thet,select]=randp(random,numEndms,W,H,Y);

% hidden layers 
for i=1:Pixels
    eps = inv(thet/Objective1);
    Mu = eps * ((1/Objective1)*(zt-pro)'*(Ya(i,:)'-Wa(select,:)'));
% hidden variable 
    Z(i,:) = combi(Z(i,:),Mu,eps); 
end
% constrain abundance
Ha = constrain(random,numEndms,Z);

H = Ha';% obtain abundance
% Assure weight W of decoder, and W equals endmember matrix.

maxiteraion=50; %learning endmember
lam = 1 - delta;
[W] = endm_minv(Y,W,H,maxiteraion,lam,numEndms); % MinVol constrain endmembers
ObNew = sum(sum((Y-W*H).^2));
RMSE = [RMSE, ObNew];
if strcmp(plot_a_t, 'yes')
p = numEndms;
[y1,Up,~,~] = dataProj(Y,p,'proj_type','affine');
y1=Up'*y1;
Mtrue = Up'*M_true;
Mendms = Up'*W;
I = 1;
J = 2;
K = 3;
E_I = eye(p);
v1 = E_I(:,I);
v2 = E_I(:,J);
v3 = E_I(:,K);
y1 = [v1 v2 v3]'*y1;
m_true = [v1 v2 v3]'*Mtrue;
m_mendms=[v1 v2 v3]'*Mendms;
mm = m_true;

figure(100)
scatter3(y1(1,:),y1(2,:),y1(3,:),20);
hold on;
plot3(m_true(1,[1:end 1]), m_true(2,[1:end 1]),m_true(3,[1:end 1]),'black-','MarkerSize',30);
plot3(m_true(1,[1:end 2]),m_true(2,[1:end 2]),m_true(3,[1:end 2]), 'black-','MarkerSize',30);
plot3(m_true(1,[1:1 3]),m_true(2,[1:1 3]),m_true(3,[1:1 3]), 'black-','MarkerSize',30);
plot3(mm(1,:),mm(2,:),mm(3,:), 'black.','MarkerSize',10);
plot3(m_mendms(1,:),m_mendms(2,:),m_mendms(3,:), '^','color',[0.85,0.33,0.1],'MarkerSize',13,'LineWidth',2);
title('Training VAE','fontsize',13);
shg
drawnow;
hold  off
end
end
end